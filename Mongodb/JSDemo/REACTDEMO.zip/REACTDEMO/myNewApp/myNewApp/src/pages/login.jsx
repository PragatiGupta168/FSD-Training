import { useNavigate } from "react-router-dom"

function Login()
{
    const navigate = useNavigate()

    function loginfn()
    {
       navigate("/dash")
    }
    return(
        <>

            <h1>Login Component</h1>
            <button onClick={loginfn} className='btn btn-outline-primary'>Login</button>
            
        </>
    )
}
export default Login 