function ViewUser()
{

    return(
        <>

            <h1>View All Users Component</h1>
            
        </>
    )
}
export default ViewUser 