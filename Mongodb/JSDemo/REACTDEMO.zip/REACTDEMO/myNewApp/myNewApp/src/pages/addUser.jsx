function AddUser()
{

    return(
        <>

            <h1>Add new User Component</h1>
            
        </>
    )
}
export default AddUser 