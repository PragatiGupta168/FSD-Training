function About()
{

    return(
        <>

            <h1>About Component</h1>
            
        </>
    )
}
export default About 