function Comp5()
{
    const myStyle = {padding: '20px', backgroundColor: "navy", color: 'yellow'}



    return (

        <>
            <h1 style={{backgroundColor: '#aabbcc', lineHeight: '100px'}}>Component 5</h1>

            <p style={myStyle}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum pariatur quas aspernatur sunt similique, harum tempora, eius voluptatum recusandae corporis nobis sequi sed facere nesciunt dolorem beatae delectus deserunt! Ex?
            </p>
        
        </>


    )
}
export default Comp5