function Comp9(){


    let userNames =["Sachin", "Virat", "Rahul", "Mahi"]
    return(
        <>
        <ul>
            {
                userNames.map((name)=>(
                                        <li> {name} </li> 
                                      )
                            )
            }
        </ul>
        
        
        </>

    )


}

export default Comp9