import { Component } from "react";

// class component
class MyNewComponent extends Component
{
    render()
    {
        return(
        <>
            <h1 align='center'>My First Class Component</h1>
        </>
    )
    }

}

export default MyNewComponent