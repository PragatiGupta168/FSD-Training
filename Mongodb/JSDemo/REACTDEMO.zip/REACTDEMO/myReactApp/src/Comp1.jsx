
//Functional Component
function Comp1()
{


    return(
         // this is called fragment <>
         <>
            <h1 align='center'>My First Component</h1>
            <h1 align='center'>My First Component</h1>
        </>
    )

}


export default Comp1