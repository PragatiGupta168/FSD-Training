
// Conditional Rendering
//component k andar if-else write nhi karte means jsx me return k andar

function ValidUser()
{
    return(
        <>
            <h1 className="alert alert-success">User Is Valid</h1>
        </>
    )
}

function InValidUser()
{
    return(
        <>
            <h1 className="alert alert-warning">User Is InValid</h1>
        </>
    )
}



function Comp7()
{
    let isValid = true
    if (isValid)
        return <ValidUser/>
    else
        return <InValidUser/>
    
}
export default Comp7