

function Comp6()
{

    return(

        <>
            <p className="alert alert-info">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit quasi mollitia quis quas incidunt doloribus ex facilis doloremque obcaecati accusantium eos architecto illum excepturi deleniti velit, voluptates corrupti culpa molestias.
            </p>
        </>



    )
}
export default Comp6