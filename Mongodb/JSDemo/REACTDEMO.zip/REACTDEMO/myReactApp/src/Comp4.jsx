function Comp4()
{

    let name = 'Sachin'
    let age = 45
    let hobbies = ["Swimming", "Reading", "Dancing"]
    let user = {unm: 'Virat', gender: 'Male'}
    let marks = {Maths : 46, English: 48, Science: 45}

    return(

        <>

            <p>
                Welcome {name}, Age is {age} <br/>
                Hobbies {hobbies}<br/>
                 {hobbies[0]}
                 {user.unm }

                
            </p>
        
        </>

    )



}
export default Comp4