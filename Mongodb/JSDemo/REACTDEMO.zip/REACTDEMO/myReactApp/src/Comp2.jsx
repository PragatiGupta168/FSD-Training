function Comp2()
{


    return(
        
        <h1 align='center'>My Second Component</h1>
    )

}


export default Comp2