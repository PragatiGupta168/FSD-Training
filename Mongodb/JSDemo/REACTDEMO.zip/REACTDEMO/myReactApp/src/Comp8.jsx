
function CompA()
{
    return (

        <>
         <h1> Component A</h1>

        </>

    )
}

function CompB()
{
    return (

        <>
         <h1> Component B</h1>

        </>
    )
}

// Conditional Rendering - Variation 2 and 3
function Comp8()
{
    let name = ""
    return(

        <>
        
        {/* {name && <h2> Welcome {name} </h2>} */}

        {name ? <CompA/> : <CompB/>}
        
        </>


    )


}
export default Comp8