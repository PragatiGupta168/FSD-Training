function Comp10()
{

 let count = 0;

 function btnClick()
 {
    alert('Hi...')
 }

 function btnClick2(name)
 {
    alert('Welcome ' + name)
 }
    
    return(
        <>
    
        Count : {count} <br/>
        <button className= "btn btn-danger" onClick={btnClick}>Button 1</button> 
         {/*parameterized function alwys call in anonymous function  */}
         <button className= "btn btn-info" onClick={()=>btnClick2('Sachin')}>Button 2</button>
        {/* <button className= "btn btn-info" onClick={btnClick2('Sachin')}>Button 2</button> */}
        
        </>

    )


}

export default Comp10